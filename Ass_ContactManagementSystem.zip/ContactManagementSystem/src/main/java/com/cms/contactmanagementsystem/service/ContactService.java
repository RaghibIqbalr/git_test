package com.cms.contactmanagementsystem.service;

import com.cms.contactmanagementsystem.model.Contact;

import java.util.List;
import java.util.UUID;


public interface ContactService {
    Contact saveContact(Contact contact);
    List<Contact> fetchAllContacts();

    boolean deleteContact(Contact contact);

    Contact updateContact(Contact contact);
}
