package com.cms.contactmanagementsystem.util;

public class AppConstant {

	public static final String NO_DATA_FOUND_ERROR_MESSAGE = "No Data Found ! ! !";
	public static final String EXCEPTION_ERROR_MESSAGE = "Internal Server Error ! ! !";
	public static final String BASE_CONTEXT = "api/products";
}
