package com.cms.contactmanagementsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.contactmanagementsystem.exception.ContactNotFoundException;
import com.cms.contactmanagementsystem.model.Contact;
import com.cms.contactmanagementsystem.repository.ContactRepository;

@Service
public class ContactServiceImplementation implements ContactService {

	@Autowired
	private ContactRepository contactRepository;

	@Override
	public Contact saveContact(Contact contact) {
		contactRepository.save(contact);
		return contact;
	}

	@Override
	public Contact updateContact(Long id, Contact contact) {
		Optional<Contact> optionalContact = contactRepository.findById(id);
		if (optionalContact.isPresent()) {
			contact.setId(id);
			return contactRepository.save(contact);
		}
		throw new ContactNotFoundException("Requested contact not found in db ! ! ");
	}

	@Override
	public Contact fetchContactById(Long id) {
		return contactRepository.findById(id).orElse(null);
	}

	@Override
	public List<Contact> fetchAllContacts() {
		return contactRepository.findAll();
	}

	@Override
	public void deleteContact(Long id) {
		contactRepository.deleteById(id);
	}

}
