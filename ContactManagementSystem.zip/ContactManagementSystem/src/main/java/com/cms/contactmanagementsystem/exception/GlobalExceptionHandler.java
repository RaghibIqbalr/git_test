package com.cms.contactmanagementsystem.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import lombok.extern.slf4j.Slf4j;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

	@ExceptionHandler(ContactNotFoundException.class)
	public ResponseEntity<Object> handleContactNotFoundExcpetion(ContactNotFoundException ex, WebRequest request) {
		ExceptionResponse response = ExceptionResponse.builder().message(ex.getMessage()).timeStamp(LocalDateTime.now())
				.status(HttpStatus.NOT_FOUND.toString()).details(request.getDescription(false)).build();
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
	}
}
