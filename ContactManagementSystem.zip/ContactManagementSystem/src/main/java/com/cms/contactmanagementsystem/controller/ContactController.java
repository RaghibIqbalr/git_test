package com.cms.contactmanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cms.contactmanagementsystem.exception.ContactNotFoundException;
import com.cms.contactmanagementsystem.model.Contact;
import com.cms.contactmanagementsystem.service.ContactService;
import com.cms.contactmanagementsystem.util.AppConstant;

@CrossOrigin(origins = { "http://localhost:3000" })
@RestController
@RequestMapping("cms/api/contact")
public class ContactController {

	@Autowired
	private ContactService contactService;

	@PostMapping
	public ResponseEntity<Contact> saveContact(@RequestBody Contact contact) {
		Contact condResult = contactService.saveContact(contact);
		return new ResponseEntity<>(condResult, HttpStatus.CREATED);
	}

	@PutMapping("/{id}")
	public ResponseEntity<Contact> updateContact(@PathVariable Long id, @RequestBody Contact contact) {
		Contact updateContact = contactService.updateContact(id, contact);
		if (updateContact != null) {
			return new ResponseEntity<>(updateContact, HttpStatus.OK);
		}
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/{id}")
	public ResponseEntity<Contact> fetchContactById(@PathVariable Long id) {
		Contact contact = contactService.fetchContactById(id);
		if (contact != null) {
			return new ResponseEntity<>(contact, HttpStatus.OK);
		}
		throw new ContactNotFoundException(AppConstant.NO_DATA_FOUND_ERROR_MESSAGE);
	}

	@GetMapping
	public ResponseEntity<List<Contact>> fetchAllContacts() {
		List<Contact> contactList = contactService.fetchAllContacts();
		if (contactList.isEmpty()) {
			throw new ContactNotFoundException(AppConstant.NO_DATA_FOUND_ERROR_MESSAGE);
		}
		return new ResponseEntity<>(contactList, HttpStatus.OK);
	}

	@DeleteMapping("/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void deleteContact(@PathVariable Long id) {
		contactService.deleteContact(id);
	}

}