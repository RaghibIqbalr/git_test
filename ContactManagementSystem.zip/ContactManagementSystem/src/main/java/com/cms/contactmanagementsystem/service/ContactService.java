package com.cms.contactmanagementsystem.service;

import java.util.List;

import com.cms.contactmanagementsystem.model.Contact;

public interface ContactService {
	
	Contact saveContact(Contact contact);
	
	Contact updateContact(Long id, Contact contact);
	
	Contact fetchContactById(Long id);

	List<Contact> fetchAllContacts();

	void deleteContact(Long id);

	
}
